// ============================================================
// Name:    Kwadwo Owusu
// Date:    18/04/2026
// Course:  SDC320K — Week 1 Project
// Purpose: Composition class that manages all contacts.
//          Contains a List of Contact objects (COMPOSITION).
//          Handles add, remove, display, search, and update.
// ============================================================

using System;
using System.Collections.Generic;

namespace RolodexApp
{
    class Rolodex
    {
        // COMPOSITION — Rolodex "has a" list of Contact objects
        private List<Contact> contacts = new List<Contact>();

        // ADD
        public void AddContact()
        {
            Console.WriteLine("\nSelect Contact Type:");
            Console.WriteLine("  1. Business Contact");
            Console.WriteLine("  2. Family Contact");
            Console.WriteLine("  3. Friend Contact");
            Console.Write("Your choice: ");
            string typeChoice = Console.ReadLine();

            Console.Write("\nEnter First Name : ");
            string firstName = Console.ReadLine();
            Console.Write("Enter Last Name  : ");
            string lastName = Console.ReadLine();
            Console.Write("Enter Phone      : ");
            string phone = Console.ReadLine();
            Console.Write("Enter Email      : ");
            string email = Console.ReadLine();
            Console.Write("Enter Address    : ");
            string address = Console.ReadLine();

            if (typeChoice == "1")
            {
                Console.Write("Enter Company    : ");
                string company = Console.ReadLine();
                Console.Write("Enter Job Title  : ");
                string jobTitle = Console.ReadLine();
                contacts.Add(new BusinessContact(firstName, lastName, phone, email, address, company, jobTitle));
            }
            else if (typeChoice == "2")
            {
                Console.Write("Enter Relationship (e.g. Brother): ");
                string relationship = Console.ReadLine();
                contacts.Add(new FamilyContact(firstName, lastName, phone, email, address, relationship));
            }
            else
            {
                Console.Write("Enter Birthday (e.g. Jan 1): ");
                string birthday = Console.ReadLine();
                contacts.Add(new FriendContact(firstName, lastName, phone, email, address, birthday));
            }

            Console.WriteLine("\n✔ Contact added successfully!\n");
        }

        // REMOVE
        public void RemoveContact()
        {
            Console.Write("\nEnter last name of contact to remove: ");
            string lastName = Console.ReadLine();
            Contact toRemove = null;

            foreach (Contact c in contacts)
            {
                if (c.LastName.ToLower() == lastName.ToLower())
                {
                    toRemove = c;
                    break;
                }
            }

            if (toRemove != null)
            {
                Console.Write($"Are you sure you want to remove '{toRemove.FullName}'? (Y/N): ");
                if (Console.ReadLine().ToUpper() == "Y")
                {
                    contacts.Remove(toRemove);
                    Console.WriteLine("✔ Contact removed.\n");
                }
                else
                {
                    Console.WriteLine("Removal cancelled.\n");
                }
            }
            else
            {
                Console.WriteLine("Contact not found.\n");
            }
        }

        // DISPLAY ALL
        public void DisplayAllContacts()
        {
            if (contacts.Count == 0)
            {
                Console.WriteLine("\nNo contacts found.\n");
                return;
            }
            Console.WriteLine($"\n=== All Contacts ({contacts.Count} total) ===\n");
            foreach (Contact c in contacts)
            {
                c.DisplayContact();
            }
        }

        // DISPLAY BY LAST NAME LETTER
        public void DisplayByLastNameLetter()
        {
            Console.Write("\nEnter a letter to search last names (e.g. A): ");
            string input = Console.ReadLine().Trim().ToUpper();

            if (string.IsNullOrWhiteSpace(input))
            {
                Console.WriteLine("No letter entered.\n");
                return;
            }

            char letter = input[0];
            bool found = false;

            Console.WriteLine($"\n=== Contacts whose last name begins with '{letter}' ===\n");
            foreach (Contact c in contacts)
            {
                if (c.LastName.ToUpper().StartsWith(letter.ToString()))
                {
                    c.DisplayContact();
                    found = true;
                }
            }

            if (!found)
                Console.WriteLine($"No contacts found with last name starting with '{letter}'.\n");
        }

        // UPDATE
        public void UpdateContact()
        {
            Console.Write("\nEnter last name of contact to update: ");
            string lastName = Console.ReadLine();
            Contact toUpdate = null;

            foreach (Contact c in contacts)
            {
                if (c.LastName.ToLower() == lastName.ToLower())
                {
                    toUpdate = c;
                    break;
                }
            }

            if (toUpdate != null)
            {
                Console.WriteLine($"\nUpdating '{toUpdate.FullName}' — press Enter to keep current value:\n");
                toUpdate.UpdateContact();
                Console.WriteLine("\n✔ Contact updated successfully!\n");
            }
            else
            {
                Console.WriteLine("Contact not found.\n");
            }
        }

        // SAMPLE DATA
        public void LoadSampleContacts()
        {
            contacts.Add(new BusinessContact("Kofi",  "Asante",  "030-555-6666", "k.asante@corp.com",   "Tema, Ghana",       "TechGhana Ltd",   "Software Engineer"));
            contacts.Add(new BusinessContact("Abena", "Osei",    "020-777-8888", "abena@biz.com",       "Takoradi, Ghana",   "Osei & Partners", "Senior Accountant"));
            contacts.Add(new FamilyContact  ("Kwame", "Mensah",  "024-111-2222", "kwame@gmail.com",     "Accra, Ghana",      "Brother"));
            contacts.Add(new FamilyContact  ("Efua",  "Mensah",  "024-999-0000", "efua@gmail.com",      "Accra, Ghana",      "Mother"));
            contacts.Add(new FriendContact  ("Ama",   "Boateng", "050-333-4444", "ama.b@yahoo.com",     "Kumasi, Ghana",     "July 4"));
            contacts.Add(new FriendContact  ("Yaw",   "Darko",   "026-222-3333", "yaw.d@gmail.com",     "Cape Coast, Ghana", "December 12"));
        }
    }
}