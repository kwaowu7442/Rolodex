// ============================================================
// Name:    Kwadwo Owusu
// Date:    18/04/2026
// Course:  SDC320K — Week 1 Project
// Purpose: Derived class inheriting from Contact.
//          Adds Birthday field for friend contacts.
// ============================================================

using System;

namespace RolodexApp
{
    class FriendContact : Contact
    {
        public string Birthday { get; set; }

        public FriendContact(string firstName, string lastName, string phone, string email, string address, string birthday)
            : base(firstName, lastName, phone, email, address)
        {
            Birthday = birthday;
        }

        public override void DisplayContact()
        {
            base.DisplayContact();
            Console.WriteLine($"  Birthday: {Birthday}");
            Console.WriteLine($"  Type    : {GetContactType()}");
            Console.WriteLine("-----------------------------");
        }

        public override void UpdateContact()
        {
            base.UpdateContact();
            Console.Write($"  Birthday [{Birthday}]: ");
            string input = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(input)) Birthday = input;
        }

        public override string GetContactType()
        {
            return "Friend Contact";
        }
    }
}