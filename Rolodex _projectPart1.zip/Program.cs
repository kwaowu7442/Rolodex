﻿// ============================================================
// Name:    Kwadwo Owusu
// Date:    18/04/2026
// Course:  SDC320K — Week 1 Project
// Purpose: Main entry point for the Rolodex application.
//          Displays the menu and handles all user interaction.
// ============================================================

using System;

namespace RolodexApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("============================================");
            Console.WriteLine("  Week 1 Project | SDC320K | Kwadwo Owusu ");
            Console.WriteLine("============================================");
            Console.WriteLine("       Welcome to My Rolodex App!          ");
            Console.WriteLine("   \"Your contacts, organised and ready.\"   ");
            Console.WriteLine("============================================");
            Console.WriteLine();
            Console.WriteLine("This app demonstrates:");
            Console.WriteLine("  • Inheritance  (Business, Family & Friend extend Contact)");
            Console.WriteLine("  • Composition  (Rolodex contains a list of Contacts)");
            Console.WriteLine();

            Rolodex rolodex = new Rolodex();
            rolodex.LoadSampleContacts();
            Console.WriteLine("✔ Sample contacts loaded. Press any key to start...");
            Console.ReadKey();

            bool running = true;
            while (running)
            {
                Console.WriteLine("\n============ MAIN MENU ============");
                Console.WriteLine("  1. Add a Contact");
                Console.WriteLine("  2. Remove a Contact");
                Console.WriteLine("  3. Display All Contacts");
                Console.WriteLine("  4. Display by Last Name Letter");
                Console.WriteLine("  5. Update a Contact");
                Console.WriteLine("  6. Exit");
                Console.WriteLine("===================================");
                Console.Write("Your choice: ");

                string choice = Console.ReadLine();
                switch (choice)
                {
                    case "1": rolodex.AddContact();              break;
                    case "2": rolodex.RemoveContact();           break;
                    case "3": rolodex.DisplayAllContacts();      break;
                    case "4": rolodex.DisplayByLastNameLetter(); break;
                    case "5": rolodex.UpdateContact();           break;
                    case "6":
                        running = false;
                        Console.WriteLine("\nThank you for using My Rolodex App. Goodbye! 👋");
                        break;
                    default:
                        Console.WriteLine("\nInvalid option. Please enter 1–6.\n");
                        break;
                }
            }
        }
    }
}