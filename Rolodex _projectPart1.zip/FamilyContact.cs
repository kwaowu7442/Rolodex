// ============================================================
// Name:    Kwadwo Owusu
// Date:    18/04/2026
// Course:  SDC320K — Week 1 Project
// Purpose: Derived class inheriting from Contact.
//          Adds Relationship field for family contacts.
// ============================================================

using System;

namespace RolodexApp
{
    class FamilyContact : Contact
    {
        public string Relationship { get; set; }

        public FamilyContact(string firstName, string lastName, string phone, string email, string address, string relationship)
            : base(firstName, lastName, phone, email, address)
        {
            Relationship = relationship;
        }

        public override void DisplayContact()
        {
            base.DisplayContact();
            Console.WriteLine($"  Relation: {Relationship}");
            Console.WriteLine($"  Type    : {GetContactType()}");
            Console.WriteLine("-----------------------------");
        }

        public override void UpdateContact()
        {
            base.UpdateContact();
            Console.Write($"  Relationship [{Relationship}]: ");
            string input = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(input)) Relationship = input;
        }

        public override string GetContactType()
        {
            return "Family Contact";
        }
    }
}