// ============================================================
// Name:    Kwadwo Owusu
// Date:    18/04/2026
// Course:  SDC320K — Week 1 Project
// Purpose: Derived class that inherits from Contact.
//          Represents a business contact with Company and Job Title.
// ============================================================

using System;

namespace RolodexApp
{
    // DERIVED CLASS — inherits from Contact (INHERITANCE)
    class BusinessContact : Contact
    {
        public string Company  { get; set; }
        public string JobTitle { get; set; }

        // Constructor calls base class constructor
        public BusinessContact(string firstName, string lastName, string phone, string email, string address, string company, string jobTitle)
            : base(firstName, lastName, phone, email, address)  // INHERITANCE — calling base constructor
        {
            Company  = company;
            JobTitle = jobTitle;
        }

        public override void DisplayContact()
        {
            base.DisplayContact();
            Console.WriteLine($"  Company : {Company}");
            Console.WriteLine($"  Title   : {JobTitle}");
            Console.WriteLine($"  Type    : {GetContactType()}");
            Console.WriteLine("-----------------------------");
        }

        public override void UpdateContact()
        {
            base.UpdateContact();
            Console.Write($"  Company [{Company}]: ");
            string input = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(input)) Company = input;

            Console.Write($"  Job Title [{JobTitle}]: ");
            input = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(input)) JobTitle = input;
        }

        public override string GetContactType()
        {
            return "Business Contact";
        }
    }
}