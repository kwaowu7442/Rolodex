// ============================================================
// Name:    Kwadwo Owusu
// Date:    18/04/2026
// Course:  SDC320K — Week 1 Project
// Purpose: Base class for all contact types in the Rolodex app.
//          All other contact classes inherit from this class.
// ============================================================

using System;

namespace RolodexApp
{
    // BASE CLASS — all contact types inherit from this
    class Contact
    {
        // Properties used for searching and displaying in Rolodex.cs
        public string FirstName { get; set; }
        public string LastName  { get; set; }
        public string Phone     { get; set; }
        public string Email     { get; set; }
        public string Address   { get; set; }

        // Added this to fix the "toUpdate.FullName" error in rolodex.cs
        public string FullName => $"{FirstName} {LastName}";

        // Constructor updated to take FirstName and LastName separately
        public Contact(string firstName, string lastName, string phone, string email, string address)
        {
            FirstName = firstName;
            LastName  = lastName;
            Phone     = phone;
            Email     = email;
            Address   = address;
        }

        public virtual void DisplayContact()
        {
            Console.WriteLine("-----------------------------");
            Console.WriteLine($"  Name    : {FullName}");
            Console.WriteLine($"  Phone   : {Phone}");
            Console.WriteLine($"  Email   : {Email}");
            Console.WriteLine($"  Address : {Address}");
        }

        // FIX FOR CS0115: Providing the virtual method for child classes to override
        public virtual void UpdateContact()
        {
            Console.Write($"  First Name [{FirstName}]: ");
            string input = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(input)) FirstName = input;

            Console.Write($"  Last Name [{LastName}]: ");
            input = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(input)) LastName = input;

            Console.Write($"  Phone [{Phone}]: ");
            input = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(input)) Phone = input;

            Console.Write($"  Email [{Email}]: ");
            input = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(input)) Email = input;

            Console.Write($"  Address [{Address}]: ");
            input = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(input)) Address = input;
        }

        public virtual string GetContactType()
        {
            return "General Contact";
        }
    }
}